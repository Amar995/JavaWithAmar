Build command - mvn assembly:assembly -DdescriptorId=jar-with-dependencies package

Lambda Hander Class - com.example.howtodoinjava.alexa.SayHelloRequestStreamHandler