package com.howtodoinjava.java7;

public interface CustomInterface {
    public abstract void method();
}
