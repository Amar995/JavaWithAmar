package com.howtodoinjava.java7;

public class CustomClass implements CustomInterface {
    @Override
    public void method() {
        System.out.println("Hello World");
    }

    public static void main(String[] args){
        CustomInterface instance = new CustomClass();
        instance.method();
    }
}
