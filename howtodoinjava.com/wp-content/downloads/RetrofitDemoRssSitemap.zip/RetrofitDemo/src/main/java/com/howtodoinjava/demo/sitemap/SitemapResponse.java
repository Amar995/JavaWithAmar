package com.howtodoinjava.demo.sitemap;

import java.util.ArrayList;

import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

@Root(name = "urlset")
public class SitemapResponse 
{
	@ElementList(name = "url", inline = true)
	private ArrayList<SitemapEntry> url;

	@Override
	public String toString() {
		return "SitemapResponse [urlset=" + url + "]";
	}
}
