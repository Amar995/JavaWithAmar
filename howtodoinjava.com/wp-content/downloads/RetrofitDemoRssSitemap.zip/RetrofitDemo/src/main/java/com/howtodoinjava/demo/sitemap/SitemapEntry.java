package com.howtodoinjava.demo.sitemap;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name="url")
public class SitemapEntry 
{
	@Element(name="loc")
	private String loc;
	
	@Element(name="lastmod")
	private String lastmod;
	
	@Element(name="changefreq")
	private String changefreq;
	
	@Element(name="priority")
	private float priority;
	
	@Override
	public String toString() {
		return "SitemapEntry [loc=" + loc + ", lastmod=" + lastmod + ", changefreq=" + changefreq + ", priority=" + priority
				+ "]";
	}
}
