package com.howtodoinjava.demo.sitemap;

import retrofit2.Call;
import retrofit2.http.GET;

public interface SitemapService 
{
	@GET("sitemap.xml") Call<SitemapResponse> getFeed();
}
