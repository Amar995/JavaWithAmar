package com.howtodoinjava.demo.rss;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.simplexml.SimpleXmlConverterFactory;

public class RssServiceDemo {
	private static final String BASE_URL = "https://howtodoinjava.com/";

	private static Retrofit.Builder builder = new Retrofit.Builder().baseUrl(BASE_URL)
			.addConverterFactory(SimpleXmlConverterFactory.create());

	private static HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor()
			.setLevel(HttpLoggingInterceptor.Level.BODY);

	private static OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

	public static void main(String[] args) throws IOException {
		httpClient.addInterceptor(loggingInterceptor);
		builder.client(httpClient.build());

		Retrofit retrofit = builder.build();

		RssService rssService = retrofit.create(RssService.class);

		Call<RssFeed> callAsync = rssService.getFeed();

		callAsync.enqueue(new Callback<RssFeed>() {
			@Override
			public void onResponse(Call<RssFeed> call, Response<RssFeed> response) {
				if (response.isSuccessful()) {
					RssFeed apiResponse = response.body();
					// API response
					System.out.println(apiResponse);
				} else {
					System.out.println("Request Error :: " + response.errorBody());
				}
			}

			@Override
			public void onFailure(Call<RssFeed> call, Throwable t) {
				if (call.isCanceled()) {
					System.out.println("Call was cancelled forcefully");
				} else {
					System.out.println("Network Error :: " + t.getLocalizedMessage());
				}
			}
		});
	}
}
