package com.howtodoinjava.demo;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserServiceClient 
{
	public static void main(String[] args) 
	{
		UserService service = ServiceGenerator.createService(UserService.class);
		
		Call<UserApiResponse> callSync = service.getUser(2);
		
		ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
		Call<UserApiResponse> callAsync = callSync.clone();
		
		executor.schedule(new Runnable() 
		{
			@Override public void run() 
			{
				callAsync.enqueue(new Callback<UserApiResponse>() 
				{
					@Override
					public void onResponse(Call<UserApiResponse> call, Response<UserApiResponse> response) 
					{
						if (response.isSuccessful()) {
							UserApiResponse apiResponse = response.body();
							//API response
						    System.out.println(apiResponse);
						} else {
							System.out.println("Request Error :: " + response.errorBody());
						}
					}
			
					@Override
					public void onFailure(Call<UserApiResponse> call, Throwable t) 
					{
						if(call.isCanceled()) {
							System.out.println("Call was cancelled forcefully");
						} else {
							System.out.println("Network Error :: " + t.getLocalizedMessage());
						}
					}
				});
			}
	    }, 1, TimeUnit.SECONDS);
	}
}
