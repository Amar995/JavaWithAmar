package com.howtodoinjava.example;

import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ParseInt;
import org.supercsv.cellprocessor.ParseLong;
import org.supercsv.cellprocessor.constraint.NotNull;
import org.supercsv.cellprocessor.constraint.StrRegEx;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvListReader;
import org.supercsv.io.ICsvListReader;
import org.supercsv.prefs.CsvPreference;

public class ReadCSVFileWithArbitraryNumberOfColumns {

	static final String CSV_FILENAME = "data.csv";

	public static void main(String[] args) throws IOException 
	{
		try(ICsvListReader listReader = new CsvListReader(new FileReader(CSV_FILENAME), CsvPreference.STANDARD_PREFERENCE))
		{
			//First Column is header names- though we don't need it in runtime
			@SuppressWarnings("unused")
			final String[] headers = listReader.getHeader(true);
			final CellProcessor[] processors = getProcessors();

			List<Object> fieldsInCurrentRow;
			while ((fieldsInCurrentRow = listReader.read(processors)) != null) {
				System.out.println(String.format("rowNo=%s, customerList=%s", listReader.getRowNumber(), fieldsInCurrentRow));
			}
		} 
	}

	/**
	 * Sets up the processors used for the examples.
	 */
	private static CellProcessor[] getProcessors() {
		final String emailRegex = "[a-z0-9\\._]+@[a-z0-9\\.]+";
		StrRegEx.registerMessage(emailRegex, "must be a valid email address");

		final CellProcessor[] processors = new CellProcessor[] {
				new NotNull(new ParseInt()), // CustomerId
				new NotNull(), // CustomerName
				new NotNull(), // Country
				new Optional(new ParseLong()), // PinCode
				new StrRegEx(emailRegex) // Email
		};
		return processors;
	}
}
